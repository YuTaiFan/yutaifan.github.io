from sys import argv

from PyQt5.QtCore import QDateTime, QTimer, QRect
from PyQt5.QtWidgets import QMainWindow, QApplication, QTextEdit, QPushButton
from MenuBar import MenuBar
from res.index import Ui_MainWindow
from lib.Dicts import Dicts
from lib.Editor import Editor
from lib.Hitokoto import Hitokoto
from lib.Time import NewYear, Month, Day, Hour


# pyuic5 -o res/index.py res/index.ui
class JiuJiu(QMainWindow, Ui_MainWindow, MenuBar):
    def __init__(self):
        super(JiuJiu, self).__init__()
        self.setupUi(self)
        # 词典
        self.dicts = Dicts(self)
        # 编辑器
        self.editor = Editor(self)

        # 一言
        Yiyan, From = Hitokoto()
        self.label_2.setText(f'<p style="color:#ffffff">{Yiyan}&nbsp;&nbsp;&nbsp;&nbsp;--{From}</p>')
        # 壁纸
        if 7 < int(Hour) < 14:
            path = 'QWidget#index{border-image:url(res/wallpaper/qh1.jpg)}'
        elif 14 <= int(Hour) < 19:
            path = 'QWidget#index{border-image:url(res/wallpaper/qh2.jpg)}'
        else:
            path = 'QWidget#index{border-image:url(res/wallpaper/qh3.jpg)}'
        self.index.setStyleSheet(path)

        # ==========添加菜单栏按钮==========
        # 新建文件
        self.actionNew.triggered.connect(self.FileNew)
        # 保存
        self.actionSave.triggered.connect(self.FileSave)
        # 建议
        self.actionSuggests.triggered.connect(self.Suggests)

        # ==========添加主页面按钮==========
        self.pushButton_6.clicked.connect(self.Index)
        self.pushButton_8.clicked.connect(self.Document)
        self.pushButton_2.clicked.connect(self.Writing)

        # ==========添加文件页面按钮==========
        self.verticalScrollBar.valueChanged.connect(self.valueChange)

        # ==========添加写作页面按钮==========
        # 加粗
        self.pushButton_4.clicked.connect(self.editor.SetBold)
        # 斜体
        self.pushButton_5.clicked.connect(self.editor.SetItalic)
        # 左对齐
        self.pushButton_10.clicked.connect(self.editor.SetAlignLeft)
        # 中间对齐
        self.pushButton_9.clicked.connect(self.editor.SetAlignCenter)
        # 搜索
        self.pushButton.clicked.connect(self.dicts.get)

        self.Index()

    # 主页
    def Index(self):
        self.stackedWidget.setCurrentIndex(0)
        # 时间
        TimeTimer = QTimer(self)
        TimeTimer.timeout.connect(self.SetTime)
        TimeTimer.start()

    # 切换文件夹页面
    def Document(self):
        self.stackedWidget.setCurrentIndex(1)
        with open('res/document/.config', 'r') as f:
            jiutext = f.readlines()
        l = len(jiutext)
        # 文本列数
        line = 1 if l // 5 == 0 else l // 5
        # 最后一列文本行数
        linend = l % 5
        # 滑动页面高度 220=190+30
        heightPage = (line + 0 if linend else 1) * 220

        n = 0
        if l <= 5:
            for i in range(l):
                self.Button(100 + 220 * i, 30, self.widget, jiutext[n])
                n += 1
        else:
            for i in range(line):
                for j in range(5):
                    self.Button(100 + j * 220, 30 + 220 * i, self.widget, jiutext[n])
                    n += 1
            for i in range(linend):
                self.Button(100 + i * 220, 30 + 220 * line, self.widget, jiutext[n])
                n += 1

        self.verticalScrollBar.setMaximum(heightPage // 10)

    # 切换写作页面
    def Writing(self, t=''):
        self.stackedWidget.setCurrentIndex(2)
        self.textEdit.setPlainText(t)

    # 工具方法
    def valueChange(self):
        self.widget.setGeometry(QRect(self.widget.geometry().x(), -self.verticalScrollBar.value() * 10, 2000, self.kk))

    def SetTime(self):
        gettime = QDateTime.currentDateTime()
        time = gettime.toString('hh:mm')
        self.label.setText(
            f'<p style="color:#ffffff;font-weight:bold">{time}</p><p style="color:#ffffff;font-size:20px;font-weight:bold">{NewYear}年&nbsp;&nbsp;&nbsp;&nbsp;{Month}-{Day}</p>')

    def Button(self, x, y, parent, text):
        z = QRect(x, y, 150, 190)
        textEdit = QTextEdit(parent)
        textEdit.setGeometry(z)
        textEdit.setStyleSheet("QTextEdit\n"
                               "{\n"
                               "font: 25 16pt 'Microsoft YaHei UI Light';\n"
                               "padding:12px;\n"
                               "border-radius: 8px;\n"
                               "background-color: rgb(250, 250, 250);\n"
                               "}")
        textEdit.setText(f'<p align="center">{text}</p>')
        textEdit.setReadOnly(True)
        push = QPushButton(parent)
        push.clicked.connect(lambda: self.OpenFile(text))
        push.setGeometry(z)
        push.setStyleSheet("background: transparent")
        textEdit.show()
        push.show()

    def OpenFile(self, text):
        file = text.split(' ')[0]
        with open('res/document/' + file + '.jiu', 'r') as f:
            self.Writing(f.read())
        self.menubar.name = file
        self.setWindowTitle('JiuJiu-' + file)


if __name__ == '__main__':
    app = QApplication(argv)
    jiujiu = JiuJiu()
    jiujiu.show()
    app.exec_()
