from requests import get


def Hitokoto():
    try:
        response = get('https://v1.hitokoto.cn/?c=i').json()
        Yiyan = response.get('hitokoto')
        From = response.get('from')
    except:
        return '请检查网络加载语句', 'JiuJiu'

    return Yiyan, From
