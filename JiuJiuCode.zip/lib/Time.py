from time import strftime, localtime

# 初始化
TianGan = ('甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸')
DiZhi = ('子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥')

time = localtime()
Year = int(strftime('%Y', time))
Month = strftime('%m', time)
Day = strftime('%d', time)
Hour = strftime('%H', time)
Minute = strftime('%M', time)
s = strftime('%S',time)

# 计算
Gan = Year % 10 - 4
Zhi = Year % 12 - 4

NewYear = TianGan[Gan] + DiZhi[Zhi]
