from PyQt5.QtCore import Qt


class Editor(object):
    def __init__(self, win):
        self.win = win

    def SetBold(self):
        FontFormat = self.win.textEdit.currentCharFormat()
        CurrentFont = FontFormat.font()
        CurrentFont.setBold(not CurrentFont.bold())
        FontFormat.setFont(CurrentFont)
        self.win.textEdit.textCursor().mergeCharFormat(FontFormat)

    def SetItalic(self):
        FontFormat = self.win.textEdit.currentCharFormat()
        FontFormat.setFontItalic(not FontFormat.fontItalic())
        self.win.textEdit.textCursor().mergeCharFormat(FontFormat)

    def SetAlignLeft(self):
        self.win.textEdit.setAlignment(Qt.AlignLeft)

    def SetAlignCenter(self):
        self.win.textEdit.setAlignment(Qt.AlignHCenter)
