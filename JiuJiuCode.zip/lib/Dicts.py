from requests import get
from lxml.etree import HTML

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36 Edg/89.0.774.68"}
url = "https://dict.baidu.com/s?wd="


class Dicts(object):
    def __init__(self, win):
        self.win = win

    def get(self):
        response = get(url + self.win.lineEdit_3.text(), headers).text
        response = HTML(response)
        dl = response.xpath("/html/body/div[3]/div/div[3]/div[2]/div[2]/div[1]/dl")

        dl_num = len(dl)
        # 获取字词数据并排版
        if dl_num > 1:
            text = ""
            for i in dl:
                text += i.xpath("dt/text()")[0] + "\n"
                for j in range(1, len(i.xpath("dd/p")) + 1):
                    text += "\n  ".join(i.xpath(f"dd/p[{j}]//text()")).replace("：", "").replace("。", "") + "\n"
                text += "\n"
        elif dl_num == 1:
            text = dl[0].xpath("dd/p/text()")[0].strip()
        else:
            text = "未找到字词 难搞欸..."

        self.win.textEdit_2.setText(text)
