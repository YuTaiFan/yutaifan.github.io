from smtplib import SMTP
from email.mime.text import MIMEText
from email.header import Header


def qqemail(text):
    message = MIMEText(text, 'plain', 'utf-8')
    message['From'] = Header("Guest", 'utf-8')
    message['To'] = Header("Kaiy", 'utf-8')
    message['Subject'] = Header("JiuJiu", 'utf-8')

    smtpObj = SMTP()
    smtpObj.connect("smtp.qq.com", 587)  # 25 为 SMTP 端口号
    smtpObj.login("2971934557@qq.com", "aqsljmrjlhzydegc")
    smtpObj.sendmail('2971934557@qq.com', '2971934557@qq.com', message.as_string())
