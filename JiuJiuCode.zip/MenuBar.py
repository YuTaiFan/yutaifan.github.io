from os.path import exists
from PyQt5.QtWidgets import QInputDialog, QMessageBox, QLineEdit
from lib.SendEmail import qqemail
from lib.Time import Year, Month, Day


class MenuBar(object):
    def __init__(self, win):
        self.win = win
        # 文件名称
        self.name = False

    # 新建文件
    def FileNew(self):
        # k指是否点击确定
        self.name, k = QInputDialog.getText(self.win, 'New', '题目')
        if k and not exists(f"res/document/{self.name}.jiu"):
            with open(f'res/document/{self.name}.jiu', 'w'):
                pass
            with open('res/document/.config', 'a') as f:
                f.write(f'{self.name} {Year}-{Month}-{Day}\n')
            self.win.setWindowTitle('JiuJiu-' + self.name)
            self.win.textEdit.setText('')
            self.win.stackedWidget.setCurrentIndex(2)
        elif k:
            QMessageBox.warning(self.win, "Warning~", "该作文已存在或未输入题目")

    # 保存文件
    def FileSave(self):
        if self.name:
            with open(f'res/document/{self.name}.jiu', 'w') as f:
                f.write(self.win.textEdit.toHtml())

    # 建议
    def Suggests(self):
        text, k = QInputDialog.getText(self.win, "Suggests", "有啥建议哩?", QLineEdit.Normal, "")
        if text and k:
            qqemail(text)
